<?php

require_once 'include/DB_Functions.php';
$db = new DB_Functions();
 

$response = array("error" => FALSE);
 


if (isset($_POST['Shop_Name']) && isset($_POST['price']) && isset($_POST['SPF']) && isset($_POST['Latitude']) && isset($_POST['Longitude']) && isset($_POST['Shop_image']) && isset($_POST['Distance']) && isset($_POST['Product_Name']) && isset($_POST['Description']) && isset($_POST['Product_image'])&& isset($_POST['User_ID'])) {
    // Recieving the post paramter 
    $Shop_Name=$_POST['Shop_Name'];
    $price = $_POST['price'];
    $SPF = $_POST['SPF'];
    $Latitude = $_POST['Latitude'];
    $Longitude = $_POST['Longitude'];
    $Shop_image = $_POST['Shop_image'];
    $Distance = $_POST['Distance'];
    $Product_Name = $_POST['Product_Name'];
    $Description = $_POST['Description'];
    $Product_image = $_POST['Product_image'];
    $User_ID = $_POST['User_ID'];
    number_format($User_ID);
    number_format($price);
    $Distance=(int)$Distance;

    
    
    // check if product of the user is already existed
    if ($db->isUserProductExisted($User_ID,$Shop_Name,$Product_Name)) {
        // user already existed
        $response["error"] = TRUE;
        $response["error_msg"] = "User already existed with " . $Product_Name;
        echo json_encode($response);
    } 
    else {
        // create a new user
        $user_product = $db-> storeproduct($Shop_Name, $price, $SPF,$Latitude,$Longitude , $Shop_image , $Distance , $Product_Name , $Description , $Product_image , $User_ID);
        if ($user_product) {
            // user stored successfully
            $response["error"] = FALSE;
            $response["user_product"] ["Shop_Name"]= $user_product["Shop_Name"];
            $response["user_product"]["price"] = $user_product["price"];
            $response["user_product"]["SPF"] = $user_product["SPF"];
            $response["user_product"]["Latitude"] = $user_product["Latitude"];	
            $response["user_product"]["Longitude"] = $user_product["Longitude"];
            $response["user_product"]["Shop_image"] = $user_product["Shop_image"];
            $response["user_product"]["Distance"] = $user_product["Distance"];
            $response["user_product"]["Product_Name"] = $user_product["Product_Name"];
            $response["user_product"]["Description"] = $user_product["Description"];
            $response["user_product"]["Product_image"] = $user_product["Product_image"];
            $response["user_product"]["User_ID"] = $user_product["User_ID"];
            echo json_encode($response);
        } else {
            // user failed to store
            $response["error"] = TRUE;
            $response["error_msg"] = "Unknown error occurred in registration!";
            echo json_encode($response);
        }
    }


   
    

}
else{
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters ID !!!!!!";
    echo json_encode($response);


}

//displaying the result in json format 

?>