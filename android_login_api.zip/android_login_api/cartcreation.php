<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'android_api');

//connecting to database and getting the connection object
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
//Checking if any error occured while connecting
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    die();
    }




if (isset($_POST['User_ID'])){

    $User_ID=$_POST['User_ID'];
    number_format($User_ID);

    //creating a query
    $stmt = $conn->prepare("SELECT * FROM cart WHERE User_ID = ?");
    $stmt->bind_param( "i", $User_ID );

    //executing the query 
    $stmt->execute();

    //binding results to the query 
    $stmt->bind_result($CID ,$Shop_Name, $price, $SPF,$Latitude,$Longitude , $Shop_image , $Distance , $Product_Name , $Description , $Product_image , $User_ID);

    $pros = array();
   
    //traversing through all the result 
    while($stmt->fetch()){
        $temp = array();
        $temp['CID'] = $CID; 
        $temp['Shop_Name'] = $Shop_Name; 
        $temp["price"] = $price;
        $temp["SPF"] = $SPF;
        $temp["Latitude"] = $Latitude;	
        $temp["Longitude"] =$Longitude;
        $temp["Shop_image"] = $Shop_image;
        $temp["Distance"] = $Distance;
        $temp["Product_Name"] = $Product_Name;
        $temp["Description"] =$Description;
        $temp["Product_image"] = $Product_image;
        $temp["User_ID"] =  $User_ID;
        array_push($pros, $temp);
        
    }
    echo json_encode($pros);
}
else{

    $pros["error_msg"] = "Required parameters ID !!!!!!";
    echo json_encode($pros);


}

//displaying the result in json format 

?>