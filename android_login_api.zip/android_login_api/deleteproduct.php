<?php


define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'android_api');

//connecting to database and getting the connection object
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);



if (isset($_POST['CID'])){

    $CID=$_POST['CID'];
     number_format($CID);
    

    
 
     // Check connection
     if($conn === false){
         die("ERROR: Could not connect. " . mysqli_connect_error());
     }
      
     // Attempt delete query execution
     $sql = "DELETE FROM cart WHERE CID = $CID ";
     if(mysqli_query($conn, $sql)){
        $pros["error_msg"] = "Records were deleted successfully." ;
        echo json_encode($pros);
     } else{
        $pros["error_msg"] = "ERROR: Could not able to execute $sql. " . mysqli_error($conn) ;
         echo json_encode($pros);
     }
      
     // Close connection
     mysqli_close($conn);

    

    
}
else{

    $pros["error_msg"] = "Required parameters ID !!!!!!";
    echo json_encode($pros);


}

//displaying the result in json format 

?>