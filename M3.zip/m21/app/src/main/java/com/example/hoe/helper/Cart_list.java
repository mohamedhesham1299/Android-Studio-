package com.example.hoe.helper;

import android.app.Activity;

public class Cart_list extends Activity{
        private String Shop_Name;
        private int Price;
        private  int CID ;
        private String SPF;
        private String Latitude;
        private String Longitude;
        private String Shop_image ;
        private int distance;
        private String Product_name;
        private String Product_Description;
        private String Product_image;
        private  int User_ID  ;

    public int getCID() {
        return CID;
    }

    public Cart_list(int CID , String name, int price , String SPF , String lat, String log, String imj , int distance , String Product_name , String Product_description , String Product_image , int USer_ID) {
            this.CID = CID  ;
            this.Shop_Name = name;
            this.Price  = price ;
            this.SPF = SPF ;
            this.Latitude = lat;
            this.Longitude=log;
            this.Shop_image=imj ;
            this.distance = distance ;
            this.Product_name = Product_name ;
            this.Product_Description = Product_description ;
            this.Product_image = Product_image;
            this.User_ID= USer_ID ;

        }

    public String getShop_Name() {
        return Shop_Name;
    }

    public int getPrice() {
        return Price;
    }

    public String getSPF() {
        return SPF;
    }

    public String getLatitude() {
        return Latitude;
    }

    public String getLongitude() {
        return Longitude;
    }

    public String getShop_image() {
        return Shop_image;
    }

    public int getDistance() {
        return distance;
    }

    public String getProduct_name() {
        return Product_name;
    }

    public String getProduct_Description() {
        return Product_Description;
    }

    public String getProduct_image() {
        return Product_image;
    }
}
