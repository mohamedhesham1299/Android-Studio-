package com.example.hoe.helper;

import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
//import com.example.hoe.Dashboard;
import com.example.hoe.Dashboard;
import com.example.hoe.LoginActivity;
import com.example.hoe.MainActivity;
import com.example.hoe.R;
import com.example.hoe.activity.MainActivity2;
import com.example.hoe.app.AppConfig;
import com.example.hoe.app.AppController;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.tasks.Task;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.ShopViewHolder>  {
    private static ArrayList<Double> userlocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    Location currentLocation;
    private Context mCtx;
    private List<Shop_product> Shop_productList;
    private List<Shop> Shop_list;
    private Task<Location> task;
    private  List<sHelper> zz;
    private List<DisHelper> dd;
    private int sort_index ;
    private String Shop_name , Shop_image , SPF , Product_Name , Product_image,product_Description,longa , lat , User_id;
    private int distancee , price   ;





    private static final String TAG = ShopAdapter.class.getSimpleName();


//    public ShopAdapter(double a ,double b){
//        Longe=a;
//        late=b;
//
//    }

    public ShopAdapter(Context mCtx, List<sHelper> zz , int sort ,List<DisHelper> dd, Task<Location> task){
        this.zz=zz;
        this.mCtx = mCtx;
        this.sort_index = sort ;
        this.dd=dd;
//        this.Shop_productList = Shop_productList;
//        this.Shop_list=Shop_list;
   this.task=task;


    }


//    public ShopAdapter(Context mCtx, List<Shop_product> Shop_productList ){
//        this.mCtx = mCtx;
//        this.Shop_productList = Shop_productList;
//        this.myshop=myshop;
//
//    }



    public ShopViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.activity_shop_products, null);
        return new ShopViewHolder(view);

    }


    public void onBindViewHolder(ShopViewHolder holder, int position) {
//        Log.d(TAG, "SHOPLIST: " + getItemCount2());
//        Log.d(TAG, "SHOPPRDUCTLIST: " + getItemCount());
   //     fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(ShopAdapter);

       if(sort_index==0) {
           Collections.sort(zz);
           sHelper ff = zz.get(position);

           holder.textView_Shop_name.setText(ff.getShopname());
           holder.textViewSpeciall_offers.setText(ff.getSpecial_Offers());
           holder.textViewPrice.setText(String.valueOf(ff.getPrice()) + " LE ");


        double longs=Double.parseDouble(ff.getLongt());
        double lats=Double.parseDouble(ff.getLant());
           Log.d(TAG, "onBindViewHolder: "+ longs );
         // prebare distance to function
        ///////////////////////////////////////////////
        Location user = new Location("User") ;
       user.setLatitude(task.getResult().getLatitude());
        user.setLongitude(task.getResult().getLongitude());
        Location shop = new Location("shop");
        shop.setLatitude(lats);
        shop.setLongitude(longs);
        /////////////////////////////////////////////
        int distace = (int) (user.distanceTo(shop)/1000) ;
//        MainActivity.add_distance(distace);

        Log.d(TAG, "999999999999999999999999999999999999999999 " + distace);

        holder.textViewRatingShop.setText(Integer.toString(ff.getDis())+ " Km ");

           holder.addCart.setOnClickListener(new AdapterView.OnClickListener(){

               @Override
               public void onClick(View v) {
                   Shop_name = ff.getShopname() ;
                   price= ff.getPrice();
                   SPF = ff.getSpecial_Offers();
                   lat = ff.getLant() ;
                   longa = ff.getLongt() ;
                   Shop_image =ff.getImage() ;
                   distancee = distace ;
                   Product_Name = ff.getProduct_Name() ;
                   product_Description=ff.getDescription();
                   Product_image =ff.getProduct_image();
                   User_id=LoginActivity.userId ;
                   StoreProduct(Shop_name,Integer.toString(price),SPF,lat,longa,Shop_image,Integer.toString(distancee),Product_Name,product_Description,Product_image,User_id);

               }
           });

        //Log.d(TAG, "onBindViewHolder: "+dist(late,Longe,lats,longs));

        //Log.d(TAG, "PLACE IN MAP: " + s1.getShop_Name() +"  " + s1.getLatitude() + " " + s1.getLongitude() +" ");
           // this part for the shop image when we insert it
           try {
               URL Imageurl = new URL(ff.getImage());
               Glide.with(mCtx)
                       .load(Imageurl)
                       .into(holder.imageView);
           } catch (MalformedURLException e) {
               e.printStackTrace();
           }


           holder.textViewRatingShop.setOnClickListener(new AdapterView.OnClickListener(){

               @Override
               public void onClick(View v) {
                   try{
                       String q="q= "+ff.getLant()+", "+ff.getLongt();
                       Uri uri = Uri.parse("google.navigation:" +q);

                       Intent intent =new Intent(Intent.ACTION_VIEW,uri);
                       intent.setPackage("com.google.android.apps.maps");
                       intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                       mCtx.startActivity(intent);


                   }
                   catch (ActivityNotFoundException e){
                       Uri uri = Uri.parse("http://play.google.com/store/apps/details?id=com.google.android.apps.maps");
                       Intent intent =new Intent(Intent.ACTION_VIEW,uri);
                       intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                       mCtx.startActivity(intent);


                   }

               }
           });

       }
       else{
           Collections.sort(dd);
           DisHelper ff = dd.get(position);

           holder.textView_Shop_name.setText(ff.getShopname());
           holder.textViewSpeciall_offers.setText(ff.getSpecial_Offers());
           holder.textViewPrice.setText(String.valueOf(ff.getPrice()) + " LE ");

           holder.addCart.setOnClickListener(new AdapterView.OnClickListener(){

               @Override
               public void onClick(View v) {
                   Shop_name = ff.getShopname() ;
                   price= ff.getPrice();
                   SPF = ff.getSpecial_Offers();
                   lat = ff.getLat() ;
                   longa = ff.getLong() ;
                   Shop_image =ff.getImage() ;
                   distancee = ff.getDis() ;
                   Product_Name = ff.getProduct_Name() ;
                   product_Description=ff.getDescription();
                   Product_image =ff.getProduct_image();
                   User_id=LoginActivity.userId ;
                   Log.d(TAG, "onClick: "+SPF);
                   StoreProduct(Shop_name,Integer.toString(price),SPF,lat,longa,Shop_image,Integer.toString(distancee),Product_Name,product_Description,Product_image,User_id);


               }
           });


        holder.textViewRatingShop.setText(Integer.toString(ff.getDis())+ " Km ");
        //Log.d(TAG, "onBindViewHolder: "+dist(late,Longe,lats,longs));

       // this part for the shop image when we insert it
           try {
               URL Imageurl = new URL(ff.getImage());
               Glide.with(mCtx)
                       .load(Imageurl)
                       .into(holder.imageView);
           } catch (MalformedURLException e) {
               e.printStackTrace();
           }


           holder.textViewRatingShop.setOnClickListener(new AdapterView.OnClickListener(){

               @Override
               public void onClick(View v) {

                try{
                    String q="q= "+ff.getLat()+", "+ff.getLong();
                    Uri uri = Uri.parse("google.navigation:" +q);
                    Log.d(TAG, "onClick: "+uri+" "+ff.getLat()+" "+ff.getLong());
                    Intent intent =new Intent(Intent.ACTION_VIEW,uri);
                    intent.setPackage("com.google.android.apps.maps");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    mCtx.startActivity(intent);


                }
                catch (ActivityNotFoundException e){
                    Uri uri = Uri.parse("http://play.google.com/store/apps/details?id=com.google.android.apps.maps");
                    Intent intent =new Intent(Intent.ACTION_VIEW,uri);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    mCtx.startActivity(intent);


                }

               }
           });

       }

        //new Dashboard();



    }


    @Override
    public int getItemCount() {
        return zz.size();
    }


    class ShopViewHolder extends RecyclerView.ViewHolder {

        TextView  textViewSpeciall_offers, textViewPrice,textView_Shop_name , textViewRatingShop;
        ImageView imageView;
        Button addCart ;

        public ShopViewHolder(View itemView) {
            super(itemView);
            textViewRatingShop= itemView.findViewById(R.id.textViewRatingShop);
            textView_Shop_name = itemView.findViewById(R.id.textViewShop_Name);
            textViewSpeciall_offers = itemView.findViewById(R.id.textViewOfferDesc);
            textViewPrice = itemView.findViewById(R.id.textViewPrice_Shop);
            imageView = itemView.findViewById(R.id.Shop_image);
            addCart = itemView.findViewById(R.id.Addtocart) ;
        }
    }


    private void StoreProduct( final String sShop_Name , String sprice , String sSPF , String sLatitude,String sLongitude,String sShop_image,String sDistance,String pProduct_Name,String sDescription,String sProduct_image,String sUser_ID ){
        String tag_string_req = "req_cart";
        String ss = sShop_Name;
        StringRequest strReq = new StringRequest(Request.Method.POST,
                AppConfig.URL_cart, new Response.Listener<String>() {

            public void onResponse(String response){
                Log.d(TAG, "Cart Response: " +"     "+"C"+ response+"C");
                try {
                    JSONObject jObj = new JSONObject(response);
                    boolean error = jObj.getBoolean("error");

                    // Check for error node in json
                    if (!error) {
                        // product successfully Stored
                        Toast.makeText(mCtx.getApplicationContext(), " Product Stroed Successfully ", Toast.LENGTH_LONG).show();


                    } else {
                        // Error in login. Get the error message
                        String errorMsg = jObj.getString("error_msg");
                        Toast.makeText(mCtx.getApplicationContext(),
                                errorMsg, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                    Toast.makeText(mCtx.getApplicationContext(), "Json error: " + e.getMessage(), Toast.LENGTH_LONG).show();

                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Stored Error: " + error.getMessage());
                Toast.makeText(mCtx.getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                String aa = ss ;
                Map<String, String> params =new HashMap<String, String>();
                Log.d(TAG, "getspf: "+sSPF);
                params.put("Shop_Name", aa);
                params.put("price", sprice);
                params.put("SPF", sSPF);
                params.put("Latitude", sLatitude);
                params.put("Longitude", sLongitude);
                params.put("Shop_image", sShop_image);
                params.put("Distance", sDistance);
                params.put("Product_Name", pProduct_Name);
                params.put("Description", sDescription);
                params.put("Product_image", sProduct_image);
                params.put("User_ID", sUser_ID);
                Log.d(TAG, "getParams: "+aa+"    "+sprice+"   "+sSPF+"         "+sLatitude+"   "+sLongitude+"     "+sShop_image+"    "+sDistance+"   "+pProduct_Name+"  "+sDescription+"  "+sProduct_image+"   "+sUser_ID);
                Log.d(TAG, "get123: "+params.toString());
                return params;
            }

        };
        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);

    }



    }



