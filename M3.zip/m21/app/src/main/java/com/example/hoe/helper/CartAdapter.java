package com.example.hoe.helper;

import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.example.hoe.LoginActivity;
import com.example.hoe.R;
import com.example.hoe.app.AppConfig;
import com.example.hoe.app.AppController;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {
    private Context mCtx;
    private List<Cart_list> carty;

    private static final String TAG = CartAdapter.class.getSimpleName();

    public CartAdapter(Context mCtx,  List<Cart_list> carty) {
        this.mCtx = mCtx;
        this.carty = carty;
    }


    public CartAdapter.CartViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.activity_cart_adapter, null);
        return new CartAdapter.CartViewHolder(view);

    }


    public void onBindViewHolder(CartAdapter.CartViewHolder holder, int position) {
        Cart_list product = carty.get(position);
        String gg = product.getShop_Name() ;
        holder.textViewTitle.setText(gg);
        holder.textViewPrice.setText(Integer.toString(product.getPrice()));
        holder.product.setText(product.getProduct_name());
        try {
            URL Imageurl =  new URL(product.getProduct_image());
            Glide.with(mCtx)
                    .load(Imageurl)
                    .into(holder.imageView);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        try {
            URL Imageurl =  new URL(product.getShop_image());
            Glide.with(mCtx)
                    .load(Imageurl)
                    .into(holder.Shopview);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        holder.Delete.setOnClickListener(new AdapterView.OnClickListener(){

            @Override
            public void onClick(View v) {
                Log.d(TAG,"SSSSDSDSDSD"+product.getShop_Name());
                Delete(Integer.toString(product.getCID()));

            }
        });



    }

    public int getItemCount() {
        return carty.size();
    }

    class CartViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, textViewShortDesc, textViewRating, textViewPrice,product ;
        ImageView imageView , Shopview;
        RelativeLayout real1;
        Button Delete ;

        public CartViewHolder(View itemView) {
            super(itemView);
            real1=itemView.findViewById(R.id.real2);
            product= itemView.findViewById(R.id.Product_Name2);
            textViewTitle = itemView.findViewById(R.id.textViewTitle2);
            textViewShortDesc = itemView.findViewById(R.id.textViewShortDesc2);
            textViewPrice = itemView.findViewById(R.id.textViewPrice2);
            imageView = itemView.findViewById(R.id.Product_view);
            Shopview = itemView.findViewById(R.id.Shop_view);
            Delete = itemView.findViewById(R.id.delete) ;
        }
    }
    private void Delete( final String CID ){
        String tag_string_req = "Del_cart";
        StringRequest strReq = new StringRequest(Request.Method.POST,
                AppConfig.URL_Delete, new Response.Listener<String>() {

            public void onResponse(String response){
                try {
                    JSONObject jObj = new JSONObject(response);
                    boolean error = jObj.getBoolean("error");
                    // Check for error node in json
                    if (!error) {
                        // product successfully Stored
                        Toast.makeText(mCtx.getApplicationContext(), " Product Deleted ", Toast.LENGTH_LONG).show();


                    } else {
                        // Error in login. Get the error message
                        String errorMsg = jObj.getString("error_msg");
                        Toast.makeText(mCtx.getApplicationContext(),
                                errorMsg, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    // JSON error
                    Toast.makeText(mCtx.getApplicationContext(), " Product Deleted PLEASE REFRESH ", Toast.LENGTH_LONG).show();

                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Stored Error: " + error.getMessage());
                Toast.makeText(mCtx.getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to delete item
                Map<String, String> params =new HashMap<String, String>();
                params.put("CID", CID);
                return params;
            }

        };
        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);

    }

}