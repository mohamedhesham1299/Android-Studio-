package com.example.hoe.app;
public class AppConfig {

    // Server user login url
    public static String URL_LOGIN = "http://192.168.43.220/android_login_api/login.php";

    // Server user register url
    public static String URL_REGISTER = "http://192.168.43.220/android_login_api/register.php";

    /// access product table
    public  static String URL_PRODUCTS="http://192.168.43.220/android_login_api/displayprofile.php";

    // Access Shop_product Table
    public static  String URL_SHOP_PRODUCTS = "http://192.168.43.220/android_login_api/ShopProduct.php";

    // Access Shop Table
    public static  String URL_SHOP= "http://192.168.43.220/android_login_api/Shops.php";

    // Access cart Table
    public static  String URL_cart= "http://192.168.43.220/android_login_api/cart.php";
    //
    public static  String URL_cart_creation= "http://192.168.43.220/android_login_api/cartcreation.php";

    // Access cart Table
    public static  String URL_Delete= "http://192.168.43.220/android_login_api/deleteproduct.php";

}
