package com.example.hoe.helper;

//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.RecyclerView;
//
//import android.content.Context;
//import android.content.Intent;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.AdapterView;
//import android.widget.ImageView;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.android.volley.Request;
//import com.android.volley.Response;
//import com.android.volley.VolleyError;
//import com.android.volley.toolbox.StringRequest;
//import com.bumptech.glide.Glide;
//import com.example.hoe.LoginActivity;
//import com.example.hoe.MainActivity;
//import com.example.hoe.R;
//import com.example.hoe.activity.MainActivity2;
//import com.example.hoe.app.AppConfig;
//import com.example.hoe.app.AppController;
//
//import org.json.JSONException;
//import org.json.JSONObject;
//
//import java.net.MalformedURLException;
//import java.net.URL;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//public class Pelper extends RecyclerView.Adapter<Pelper.PelpViewHolder> {
//    private Context mCtx;
//    private List<Shop> myshop;
//
//    private static final String TAG = ShopAdapter.class.getSimpleName();
//
//    public Pelper(Context mCtx,List<Shop> myshop){
//        this.mCtx = mCtx;
//        this.myshop=myshop;
//
//    }
//
//
//
//    public PelpViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//        LayoutInflater inflater = LayoutInflater.from(mCtx);
//        View view = inflater.inflate(R.layout.activity_shop_products, null);
//        return new PelpViewHolder(view);
//
//    }
//
//
//    public void onBindViewHolder(PelpViewHolder holder, int position) {
//        Shop s1 = myshop.get(position);
//        holder.textView_Shop_name.setText(s1.getShop_Name());
//
//
//
//        // this part for the shop image when we insert it
////        try {
////            URL Imageurl =  new URL(s1.getImage());
////            Glide.with(mCtx)
////                    .load(Imageurl)
////                    .into(holder.Shop_image);
////        } catch (MalformedURLException e) {
////            e.printStackTrace();
////        }
//
//
//    }
//
//
//
//
//    public int getItemCount() {
//        return myshop.size();
//    }
//
//    class PelpViewHolder extends RecyclerView.ViewHolder {
//
//        TextView textView_Shop_name;
//       // ImageView Shop_image ;
//
//        public PelpViewHolder(View itemView) {
//            super(itemView);
//
//            textView_Shop_name = itemView.findViewById(R.id.textViewShop_Name);
//            // imageView = itemView.findViewById(R.id.Shop_image);
//        }
//    }
//
//
//}