package com.example.hoe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.example.hoe.activity.MainActivity2;
import com.example.hoe.app.AppConfig;
import com.example.hoe.app.AppController;
//import com.example.hoe.helper.Pelper;
import com.example.hoe.helper.DisHelper;
import com.example.hoe.helper.Product;
import com.example.hoe.helper.ProductAdapter;
import com.example.hoe.helper.SQLiteHandler;
import com.example.hoe.helper.SessionManager;
import com.example.hoe.helper.Shop;
import com.example.hoe.helper.ShopAdapter;
import com.example.hoe.helper.Shop_product;
import com.example.hoe.helper.VolleyCallback;
import com.example.hoe.helper.sHelper;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Intent;
import android.util.Log;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



public class MainActivity extends AppCompatActivity  {

    private static final String TAG = MainActivity.class.getSimpleName();
    private TextView txtName;
    private TextView Description_product;
    private Button btnLogout;
    private Button buttonloca;
    private ImageView product_Image ;
    private Button sort_button;
    Task<Location> task;


    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 99;

    //a list to store all the products
    List<Shop_product> Shop_productList;
    List<Shop> Shop_list ;
    List<sHelper> gg ;
    List<DisHelper> dd;
    List<String> ss;
    int Sort_index ;
    String Title ,Description,image;
    static List<Integer> dist ;

    //the recyclerview
    RecyclerView recylcerView2;
    RecyclerView recylcerView3;
    //private SQLiteHandler db;
    private SQLiteHandler db ;


    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        sort_button = findViewById(R.id.button);
        txtName = (TextView) findViewById(R.id.Product_Name2);
        Description_product = (TextView) findViewById(R.id.Description2);
        product_Image = (ImageView)findViewById(R.id.image2) ;
        Bundle mbundle = getIntent().getExtras();
        Bundle mbundle_shopadptor = getIntent().getExtras();
        int position ;
        String title2 ;
        String Longa , lat , Shop_Name ,Shop_image , SPF ;
        int distance , price ;
        task=fetchLocation();


        //getting the recyclerview from xml
        recylcerView2= findViewById(R.id.recylcerView2);
        recylcerView2.setHasFixedSize(true);
        recylcerView2.setLayoutManager(new LinearLayoutManager(this));
//        recylcerView3= findViewById(R.id.recylcerView3);
//        recylcerView3.setHasFixedSize(true);
//        recylcerView3.setLayoutManager(new LinearLayoutManager(this));


        //initializing the productlist
        Shop_productList = new ArrayList<>();
        Shop_list= new ArrayList<>() ;
        gg=new ArrayList<>();
        ss=new ArrayList<>();
        dist = new ArrayList<>();
        dd=new ArrayList<>();

        // SqLite database handler
        //db = new SQLiteHandler(getApplicationContext());

        // session manager
        session = new SessionManager(getApplicationContext());

        // Fetching product details from sqlite(product helper )
       // HashMap<String, String> product = db.getUserDetails();


        // getting the info from Product list using put extra
        if(mbundle!=null){
            position=mbundle.getInt("Position");
            String Position_String = Integer.toString(position);
            //Product product1 =productList.get(position); ;
            Title = mbundle.getString("Title") ;

            Description = mbundle.getString("Description");
            image = mbundle.getString("Photo") ;
            txtName.setText(Title);
            Description_product.setText(Description);
            try {
                URL Imageurl =  new URL(image);
                Glide.with(MainActivity.this)
                        .load(Imageurl)
                        .into(product_Image);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }


            //this method will fetch and parse json
            //to display it in recyclerview
            loadShop_product(Position_String);
            

            sort_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PopupMenu popupMenu = new PopupMenu(MainActivity.this,sort_button);
                    popupMenu.getMenuInflater().inflate(R.menu.popup_menu,popupMenu.getMenu());
                    popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            switch(item.getItemId()){
                                case R.id.Sort_price:
                                Sort_index = 0 ;
                                Log.d(TAG, "ggggggggggggggggggggggggggggggggggggggggggggg");
                                ShopAdapter adapters = new ShopAdapter(MainActivity.this, gg,Sort_index,dd,fetchLocation());
                                recylcerView2.setAdapter(adapters);
                                return true;
                                case R.id.Sort_distance:
                                Sort_index = 1 ;
                                ShopAdapter adapter = new ShopAdapter(MainActivity.this, gg,Sort_index,dd,fetchLocation());
                                recylcerView2.setAdapter(adapter);
                                return true;
                                default:
                                return false ;
        }
                        }

                    });
                    popupMenu.show();
                }
            });

//            ShopAdapter adapters = new ShopAdapter(MainActivity.this, gg);
//            recylcerView2.setAdapter(adapters);


//            if(mbundle_shopadptor!=null){
//
//                Longa = mbundle_shopadptor.getString("Longitude") ;
//                lat = mbundle_shopadptor.getString("Latutide") ;
//                SPF= mbundle_shopadptor.getString("SPF") ;
//                distance= mbundle_shopadptor.getInt("distance") ;
//
//                Shop_image = mbundle_shopadptor.getString("Shop_image") ;
//                Shop_Name =mbundle_shopadptor.getString("Shop_Name") ;
//                price = mbundle_shopadptor.getInt("price") ;
//                Log.d(TAG ,"SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS" + " " + Title +" Shop Name " + Shop_Name) ;
//
//
//            }
            Log.d(TAG ,"SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS" + " " + Title ) ;

        }




//        // Logout button click event
//        btnLogout.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                logoutUser();
//            }
//        });

//        // to access dashbord to get the location
//        buttonloca.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                locat();
//            }
//        });



    }


    private void loadShop_product(String position) {
       // Log.d(TAG, "onResponse: 33333333333333333333333333333333333333333" + position);
        /*
         * Creating a String Request
         * The request type is GET defined by first parameter
         * The URL is defined in the second parameter
         * Then we have a Response Listener and a Error Listener
         * In response listener we will get the JSON response as a String
         * */
        // Tag used to cancel the request
        String tag_string_req = "req_Product_shop";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, AppConfig.URL_SHOP_PRODUCTS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            //converting the string to json array object

                            JSONArray array = new JSONArray(response);

                            //traversing through all the object
                            for (int i = 0; i < array.length(); i++) {

                                //getting product object from json array
                                JSONObject Shopproduct = array.getJSONObject(i);






                                //adding the product to product list
                                Shop_productList.add(new Shop_product(
                                        Shopproduct.getInt("Service_ID"),
                                        Shopproduct.getInt("Shop_ID"),
                                        Shopproduct.getString("Available_Special_Offers"),
                                        Shopproduct.getInt("Price")

                                ));
                                int e = Shopproduct.getInt("Shop_ID");
                                loadShops(Integer.toString(e));








                            }






                            //creating adapter object and setting it to recyclerview


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }){

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to Product_shop url
                Map<String, String> params = new HashMap<String, String>();
                params.put("product_id", position);


                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(stringRequest, tag_string_req);;


    }


    public void loadShops( String pos){
        // Tag used to cancel the request
        String tag_string_req = "req_Shop";



        StringRequest strReq = new StringRequest(Request.Method.POST,
                AppConfig.URL_SHOP, new Response.Listener<String>() {

            @Override

            public void onResponse(String response){
             //  Log.d(TAG, "Shop Response: " + response  + "GGGGGGGGGSGSGSGSGSGGS");


                    try {
                        JSONObject array = new JSONObject(response);
                        //Log.d(TAG, "Shop Response: " + response  + "GGGGGGGGGSGSGSGSGSGGS");

                        //JSONObject Shop = jObj.getJSONObject("shops");

                       Shop_list.add(new Shop(
                                array.getInt("Shop_ID"),
                                array.getString("Shop_Name"),
                                array.getString("Latitude"),
                                array.getString("Longitude"),
                                array.getString("image")

                        ));


                       if(Shop_list.size()==Shop_productList.size()){


                           Location user = new Location("User") ;
                           user.setLatitude(task.getResult().getLatitude());
                            user.setLongitude(task.getResult().getLongitude());


                           for(int i = 0; i<Shop_productList.size();i++) {

                               Location shop = new Location("shop");
                               shop.setLatitude(Double.parseDouble(Shop_list.get(i).getLatitude()));
                               shop.setLongitude(Double.parseDouble(Shop_list.get(i).getLongitude()));
                               int distace = (int) (user.distanceTo(shop)/1000) ;
                               dd.add(new DisHelper(Shop_productList.get(i).getSpecial_Offers(), (int) Shop_productList.get(i).getPrice(), Shop_list.get(i).getShop_Name() , distace , Shop_list.get(i).getImage(),Shop_list.get(i).getLatitude(),Shop_list.get(i).getLongitude(),Title,Description,image));
                               gg.add(new sHelper(Shop_productList.get(i).getSpecial_Offers(), (int) Shop_productList.get(i).getPrice(), Shop_list.get(i).getShop_Name() , distace , Shop_list.get(i).getImage(),Shop_list.get(i).getLatitude(),Shop_list.get(i).getLongitude(),Title,Description,image)); }


                           Log.d(TAG, "000000000000000000000000000000000 " + gg.size());



                       }
                        ShopAdapter adapters = new ShopAdapter(MainActivity.this, gg,Sort_index,dd,fetchLocation());
                        recylcerView2.setAdapter(adapters);


                    }


                    catch (JSONException e) {
                        e.printStackTrace();
                        Log.d(TAG, "ERRRRRRRRRRRRRRORRRRRRRRRRRR " + e.getMessage());

                    }

//                Log.d(TAG, "NAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA: " + Shop_list.size()+"//////////////////////// "+Shop_productList.size()+"///////////////");
//

                  // callback.onSuccess(Shop_list);



            }



            },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }

                }){

        @Override
        protected Map<String, String> getParams() {
            // Posting parameters to Shop url
            Map<String, String> params = new HashMap<String, String>();
            params.put("Shop_ID", pos);

            return params;
        }

    };

    // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);


       // Log.d(TAG, "loadShops:111111111111111111111111111111111111111111111111 ");



}

    public Task<Location> fetchLocation() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);

        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
     //   Log.d(TAG, "8888888888888888888888888888888888888888888888888888888888888888888 " + task.getResult().getLatitude());




        return task;

    }



    /**
     * Logging out the user. Will set isLoggedIn flag to false in shared
     * preferences Clears the user data from sqlite users table
     * */
    private void logoutUser() {
        session.setLogin(false);

        db.deleteUsers();

        // Launching the login activity
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
//    public void showpopup(View v){
//        PopupMenu popupMenu = new PopupMenu(this,v);
//        MenuInflater inflater = popupMenu.getMenuInflater() ;
//        popupMenu.setOnMenuItemClickListener((PopupMenu.OnMenuItemClickListener) this.sort_button);
//        inflater.inflate(R.menu.popup_menu,popupMenu.getMenu());
//        popupMenu.show();
//    }

//    @Override
//    public boolean onMenuItemClick(MenuItem item) {
//        switch(item.getItemId()){
//            case R.id.Sort_price:
//                Sort_index = 0 ;
//                Log.d(TAG, "ggggggggggggggggggggggggggggggggggggggggggggg");
//                ShopAdapter adapters = new ShopAdapter(MainActivity.this, gg,Sort_index,dd,fetchLocation());
//                recylcerView2.setAdapter(adapters);
//                return true;
//            case R.id.Sort_distance:
//                Sort_index = 1 ;
//                ShopAdapter adapter = new ShopAdapter(MainActivity.this, gg,Sort_index,dd,fetchLocation());
//                recylcerView2.setAdapter(adapter);
//                return true;
//            default:
//                return false ;
//        }
//    }



    public static void add_distance(int distance){
        dist.add(distance);
    }


//    private void locat() {
//        Intent intent = new Intent(MainActivity.this, Dashboard.class);
//        startActivity(intent);
//        finish();
//
//
//    }


}