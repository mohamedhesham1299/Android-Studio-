package com.example.hoe.helper;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.hoe.MainActivity;
import com.example.hoe.R;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {
    private Context mCtx;
    private List<Product> productList;

    private static final String TAG = ProductAdapter.class.getSimpleName();

    public ProductAdapter(Context mCtx, List<Product> productList) {
        this.mCtx = mCtx;
        this.productList = productList;
    }


    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.activity_productlist, null);
        return new ProductViewHolder(view);

    }


    public void onBindViewHolder(ProductViewHolder holder, int position) {
        Product product = productList.get(position);
        int gg = product.getId() ;
        holder.textViewTitle.setText(product.getTitle());
        holder.textViewShortDesc.setText(product.getShortdesc());
        holder.textViewRating.setText(String.valueOf(product.getRating()));
    //    holder.textViewPrice.setText(String.valueOf(product.getPrice()));
        try {
            URL Imageurl =  new URL(product.getImage());
            Glide.with(mCtx)
                    .load(Imageurl)
                    .into(holder.imageView);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        holder.imageView.setOnClickListener(new AdapterView.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent myintent = new Intent(v.getContext(), MainActivity.class);
                myintent.putExtra("Position",gg);
                myintent.putExtra("Title",product.getTitle());
                myintent.putExtra("Description",product.getShortdesc());
                myintent.putExtra("Photo",product.getImage());
                mCtx.startActivity(myintent);

            }
        });
        holder.textViewTitle.setOnClickListener(new AdapterView.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent myintent = new Intent(v.getContext(), MainActivity.class);
                myintent.putExtra("Position",gg);
                myintent.putExtra("Title",product.getTitle());
                myintent.putExtra("Description",product.getShortdesc());
                myintent.putExtra("Photo",product.getImage());
                mCtx.startActivity(myintent);

            }
        });

        holder.imageView.setOnClickListener(new AdapterView.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent myintent = new Intent(v.getContext(), MainActivity.class);
                myintent.putExtra("Position",gg);
                myintent.putExtra("Title",product.getTitle());
                myintent.putExtra("Description",product.getShortdesc());
                myintent.putExtra("Photo",product.getImage());
                mCtx.startActivity(myintent);

            }
        });

        holder.real1.setOnClickListener(new AdapterView.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent myintent = new Intent(v.getContext(), MainActivity.class);
                myintent.putExtra("Position",gg);
                myintent.putExtra("Title",product.getTitle());
                myintent.putExtra("Description",product.getShortdesc());
                myintent.putExtra("Photo",product.getImage());


            }
        });



    }

    public int getItemCount() {
        return productList.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, textViewShortDesc, textViewRating, textViewPrice;
        ImageView imageView;
        RelativeLayout real1;

        public ProductViewHolder(View itemView) {
            super(itemView);
            real1=itemView.findViewById(R.id.real1);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewShortDesc = itemView.findViewById(R.id.textViewShortDesc);
            //textViewPrice = itemView.findViewById(R.id.textViewPrice);
           textViewRating = itemView.findViewById(R.id.textViewRating);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }


}