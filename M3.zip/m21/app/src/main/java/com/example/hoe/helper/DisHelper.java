package com.example.hoe.helper;

import android.app.Activity;

import com.google.android.gms.location.FusedLocationProviderClient;

public class DisHelper extends Activity implements Comparable {

    private String Special_Offers;
    private int price;
    private String shopname;
    private  int dis;
    private String lat ;
    private String longt;
    private String Product_Name  ;
    private String Description ;
    private String product_image ;

    public String getProduct_Name() {
        return Product_Name;
    }

    public String getDescription() {
        return Description;
    }

    public String getProduct_image() {
        return product_image;
    }

    public String getLat() {
        return lat;
    }
    public String getLong() {
        return longt ;
    }

    private String image;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 99;



    public String getShopname() {
        return shopname;
    }



    public String getImage() {
        return image;
    }

    public DisHelper(String Special_Offers, int price, String sname, int dis, String imj,String lat ,String longt,String product_Name , String description , String product_image) {

        this.Special_Offers = Special_Offers;
        this.price = price ;
        this.shopname = sname ;
        this.dis=dis;
        this.image = imj ;
        this.lat = lat ;
        this.longt = longt ;
        this.Product_Name = product_Name ;
        this.Description = description ;
        this.product_image = product_image ;

    }



    public String getSpecial_Offers() {
        return Special_Offers;
    }


    public int getPrice() {
        return price;
    }


    public int getDis() {
        return dis;
    }

    @Override
    public int compareTo(Object o) {
        int compareage=((DisHelper)o).getDis();

        return this.dis-compareage;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
