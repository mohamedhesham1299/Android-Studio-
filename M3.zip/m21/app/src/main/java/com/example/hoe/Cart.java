package com.example.hoe;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.hoe.MainActivity;
import com.example.hoe.R;
import com.example.hoe.app.AppConfig;
import com.example.hoe.app.AppController;
import com.example.hoe.helper.CartAdapter;
import com.example.hoe.helper.Cart_list;
import com.example.hoe.helper.DisHelper;
import com.example.hoe.helper.Product;
import com.example.hoe.helper.ProductAdapter;
import com.example.hoe.helper.Shop;
import com.example.hoe.helper.ShopAdapter;
import com.example.hoe.helper.sHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.example.hoe.app.AppConfig.URL_PRODUCTS;

public class Cart extends AppCompatActivity {
    private static final String TAG = com.example.hoe.activity.MainActivity2.class.getSimpleName();


    List<Cart_list> Cart_list = new ArrayList<>();
Button button2 ;
    // A list to store all the shops that conta

    //the recyclerview
    RecyclerView recyclerView3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        //getting the recyclerview from xml
        recyclerView3 = findViewById(R.id.recylcerView3);
        recyclerView3.setHasFixedSize(true);
        recyclerView3.setLayoutManager(new LinearLayoutManager(this));

        //initializing the cartList

        //this method will fetch and parse json
        //to display it in recyclerview
        loadcart(LoginActivity.userId);
    }




    public void loadcart( String User_id){
        // Tag used to cancel the request
        String tag_string_req = "req_Cart";



        StringRequest strReq = new StringRequest(Request.Method.POST,
                AppConfig.URL_cart_creation, new Response.Listener<String>() {

            @Override

            public void onResponse(String response){
                Log.d(TAG, "onResponse: " + response);


                try {
                    JSONArray array = new JSONArray(response);
                    for(int i=0;i<array.length();i++) {
                        JSONObject jsonobject = array.getJSONObject(i);
                        Cart_list.add(new Cart_list(
                                jsonobject.getInt("CID"),
                                jsonobject.getString("Shop_Name"),
                                jsonobject.getInt("price"),
                                jsonobject.getString("SPF"),
                                jsonobject.getString("Latitude"),
                                jsonobject.getString("Longitude"),
                                jsonobject.getString("Shop_image"),
                                jsonobject.getInt("Distance"),
                                jsonobject.getString("Product_Name"),
                                jsonobject.getString("Description"),
                                jsonobject.getString("Product_image"),
                                jsonobject.getInt("User_ID")
                        ));

                    }



                    CartAdapter c2 = new CartAdapter(Cart.this, Cart_list);
                    recyclerView3.setAdapter(c2);






                }


                catch (JSONException e) {

                }

            }

        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }

                }){

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to CartCreation url
                Map<String, String> params = new HashMap<String, String>();
                params.put("User_ID", User_id);

                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);


        // Log.d(TAG, "loadShops:111111111111111111111111111111111111111111111111 ");



    }

}