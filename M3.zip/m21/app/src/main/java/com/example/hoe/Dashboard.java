package com.example.hoe;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.RouteException;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.example.hoe.R;
import com.example.hoe.helper.ShopAdapter;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Dashboard extends AppCompatActivity implements OnMapReadyCallback, RoutingListener {
    Location currentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 99;
    private static ArrayList<Double> userlocation;
    private static final String TAG = Dashboard.class.getSimpleName();
//    private final  Task<Location> task = fetchLocation();





//    public ArrayList<Double> shit(){
//        if (ActivityCompat.checkSelfPermission(
//                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
//                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
//            return userlocation;
//        }
//        Task<Location> task = fusedLocationProviderClient.getLastLocation();
//        userlocation.add(task.getResult().getLatitude());
//        userlocation.add(task.getResult().getLongitude());
//        return userlocation;
//    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);


        fetchLocation();
    }

    public void fetchLocation() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();

        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location task) {
                if (task != null) {
                    currentLocation=task;
                    Toast.makeText(getApplicationContext(), task.getLatitude() +"," + task.getLongitude() , Toast.LENGTH_LONG).show();

                    Log.d(TAG, "222222222222222222222222222222222222222222222222222 " + task.getLatitude() );


                    SupportMapFragment supportMapFragment =(SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.map);
                    supportMapFragment.getMapAsync(new OnMapReadyCallback() {
                        @Override
                        public void onMapReady(GoogleMap googleMap) {

                            // initialize Lat Lng
                            LatLng latLng = new LatLng(task.getLatitude(),task.getLongitude());


                            // ZOOM on MAP
                            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,10));
//                            Bundle mbundle = getIntent().getExtras();
//
//                            Double slat = mbundle.getDouble("shop_lat");
//                            Double slong = mbundle.getDouble("shop_Long");
//
//                            LatLng mine = new LatLng(task.getLatitude() , task.getLongitude());
//                            LatLng shop = new LatLng(slat , slong);
//                            Findroutes(mine,shop);


                        }
                    });

                    assert supportMapFragment != null;
                    supportMapFragment.getMapAsync(Dashboard.this);
                }
                else {
                    Log.d(TAG, "88888888888888888888888888888888"+ "errooroororooror");
                }
            }
        });
    }


    public void Findroutes(LatLng start ,LatLng end ){
        if(start==null || end==null)
            Toast.makeText(Dashboard.this , "Unable to get Location ",Toast.LENGTH_LONG).show();
            else
                {


                    LatLng waypoint= start;

                    Routing routing = new Routing.Builder()
                            .travelMode(Routing.TravelMode.DRIVING)
                            .withListener(this)
                            .waypoints(start,waypoint,end)
                            .build();
                    routing.execute();



                }
        }




    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng latLng = new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude());
        // create Marker option
        MarkerOptions options = new MarkerOptions().position(latLng).title("I AM HERE ");
        // ZOOM on MAP
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,20));
        // ADD marker on map
        googleMap.addMarker(options);
        Bundle mbundle = getIntent().getExtras();

        Double slat = mbundle.getDouble("shop_lat");
        Double slong = mbundle.getDouble("shop_Long");

        LatLng mine = new LatLng( 29.988317, 31.440198);
        LatLng shop = new LatLng(slat , slong);
        Findroutes(mine,shop);



    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    fetchLocation();
                }
                break;
        }
    }

    @Override
    public void onRoutingFailure(RouteException e) {

    }

    @Override
    public void onRoutingStart() {

    }

    @Override
    public void onRoutingSuccess(ArrayList<Route> arrayList, int i) {

    }

    @Override
    public void onRoutingCancelled() {

    }
}