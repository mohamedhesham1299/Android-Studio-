package com.example.hoe.helper;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Location;

import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.tasks.Task;

public class sHelper extends Activity implements Comparable {

    private String Special_Offers;
    private int price;
    private String shopname;
    private String lant;
    private String longt;
    private String image;
    private  int dis;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 99;
    private String Product_Name  ;
    private String Description ;
    private String product_image ;

    public String getProduct_Name() {
        return Product_Name;
    }

    public String getDescription() {
        return Description;
    }

    public String getProduct_image() {
        return product_image;
    }

    public int getDis() {
        return dis;
    }

    public String getShopname() {
        return shopname;
    }

    public String getLant() {
        return lant;
    }

    public String getLongt() {
        return longt;
    }

    public String getImage() {
        return image;
    }

    public sHelper( String Special_Offers, int price, String sname, int dis, String imj,String lat ,String longt,String product_Name , String description , String product_image) {

        this.Special_Offers = Special_Offers;
        this.price = price ;
        this.shopname = sname ;
        this.dis=dis;
        this.image = imj ;
        this.lant = lat ;
        this.longt = longt ;
        this.Product_Name = product_Name ;
        this.Description = description ;
        this.product_image = product_image ;

    }



    public String getSpecial_Offers() {
        return Special_Offers;
    }


    public int getPrice() {
        return price;
    }


//    public int compareTo(sHelper comparestu) {
//        int compareage=((sHelper)comparestu).getPrice();
//
//        return this.price-compareage;
//
//
//    }


    public Task<Location> fetchLocation() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);

        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        //   Log.d(TAG, "8888888888888888888888888888888888888888888888888888888888888888888 " + task.getResult().getLatitude());




        return task;

    }



    @Override
    public int compareTo(Object o) {
        int compareage=((sHelper)o).getPrice();

        return this.price-compareage;

    }




    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
